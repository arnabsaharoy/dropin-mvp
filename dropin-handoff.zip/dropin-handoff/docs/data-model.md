# Data model

The prototype (`reference/dropin-prototype.html`) uses two flat in-memory JS
arrays, `DROPS` and `PEEPS`, plus a `userTastes` array for the signed-in user.
These are a **provisional shape**, not a final schema — real ones need proper
IDs, timestamps, relations, and RLS policies. This doc translates them into a
starting point for the actual Postgres/Supabase schema.

## `drops` (places/content — from the prototype's `DROPS`)
| prototype field | meaning | suggested column |
|---|---|---|
| `slug` | photo/place identifier | replace with `id uuid` + real `photo_url` (Mux asset or Supabase Storage) |
| `lat`, `lng` | location | `location geography(Point, 4326)` — PostGIS, enables real proximity queries |
| `mode` | live / recent / memory | derive from `created_at` + a `live_until` timestamp rather than storing a static enum — "live" should decay into "recent" automatically over time |
| `name` | place name | `place_name text` (or a `place_id` FK if places become their own table — likely worth it once a place can have many drops) |
| `hood` | neighborhood + descriptor | split into `neighborhood text` + `descriptor text` |
| `cat` | category/icon key | `category text` — keep as an enum-like lookup for icon mapping |
| `who` | array of `[user_slug, is_close_bool]` | this is really "who's going" — model as a join table `drop_attendees(drop_id, user_id, status)` rather than an array |
| `whoTxt` | pre-formatted display string | do NOT store pre-formatted HTML strings — compute this client-side or in a view from real attendee data |
| `why` | caption/description | `caption text` |
| `views` | view count | pull from Mux analytics, don't hand-maintain a counter |
| `mins` | distance/travel time | compute at query time from user location, don't store statically |

A drop's actual video lives in Mux; store only `mux_playback_id` (or asset ID) on
the row.

## `users` (people — from the prototype's `PEEPS`)
| prototype field | meaning | suggested column |
|---|---|---|
| `slug` | identifier | `id uuid` (Supabase Auth user id) |
| `lat`, `lng` | current/last-seen location | `last_location geography(Point,4326)`, with a timestamp — think about staleness/privacy here, this is sensitive |
| `name` | display name | `display_name text` |
| `tag` / `cls` | relationship to viewer ("mine", "1 yr in", "host") | do NOT store this on the user row — it's relative to the *viewer*, not an absolute property. Model as a `follows(follower_id, followee_id)` table and compute closeness/tag at query time. |
| `scene` | broad taste category | derive from `tastes`, don't store separately |
| `bio` | profile bio | `bio text` |
| `badge1`, `badge2` | earned status labels | these read as computed/earned, not free text — worth a `user_badges` table or computed view once the underlying stats (drop count, tenure, follower count) exist |
| `tastes` | array of scene tags | `user_tastes(user_id, taste_tag)` join table — this is what powers the "you both love X and Y" personalization, keep it queryable, not a JSON blob |

## `userTastes` (the signed-in user's own picks from the taste-selection screen)
Same `user_tastes` join table as above, just for the current user. This is the
one deliberate onboarding data-gather (see product-context.md) — keep it a
first-class, queryable table since real personalization depends on fast set
intersection between two users' tastes.

## Notes for schema design
- **Places probably deserve their own table** separate from drops, once you have
  more than one drop per place (the prototype already shows this — multiple
  people dropping the same place). A `places(id, name, location, neighborhood,
  category)` table with `drops.place_id` FK is likely correct.
- **"Live" should be time-derived, not a stored static field** — a drop posted 20
  minutes ago with no end time specified should probably auto-transition from
  live → recent → memory as it ages. Decide the actual decay windows (the
  prototype hints at "live · come thru" reading as very fresh, "recent" as
  same-day-ish, "memory" as a past favorite) as an actual product/data decision,
  not something to leave implicit.
- **Geo queries are the whole point of PostGIS here** — "what's near me right
  now," "people near me tonight," proximity-sorted map pins should all be real
  `ST_DWithin`/`ST_Distance` queries, not client-side filtering of an
  over-fetched dataset.
- **Row-level security**: invite-only access and the "your people vs. everyone"
  visibility distinction (see design-system.md's trust-graph pattern) both need
  real RLS policies in Supabase, not just client-side filtering.
