# DropIn

A Gen Z social app for San Francisco. People-first discovery: find people like you,
find their places, through real "Drops" (short video + location + timestamp).

Read `docs/product-context.md` before making any product-judgment call (what a
feature should do, what copy should say, what the priority order is). Read
`docs/design-system.md` before writing any UI. Read `docs/data-model.md` before
touching the database schema or API contracts. Read `docs/engineering.md` for
project-specific conventions (state management, migrations, folder structure,
secrets, testing, git) that must stay consistent across sessions. These four
files are the source of truth — this file is just the map to them.

## Tech stack (locked)
- **Client:** Flutter (iOS first, Android-ready)
- **Backend:** Supabase — Postgres + PostGIS for geo queries, Auth, Realtime, Storage
  for non-video assets. Chosen specifically because it's Postgres underneath: if we
  ever self-host on our own Node/AWS layer, it's an infrastructure swap, not a
  data-model rewrite. Do not introduce Firestore/NoSQL patterns.
- **Video:** Mux — all Drop video upload, transcoding, delivery, and analytics
  (view counts, watch time). Postgres only stores the Mux playback ID per drop.
  Do not roll a custom video pipeline or use Supabase Storage for video.
- **Push notifications:** Firebase Cloud Messaging ONLY. No other Firebase product
  in the stack. Triggered from Supabase via DB webhook or Edge Function.

## Reference implementation
`reference/dropin-prototype.html` is a working, clickable HTML/JS prototype of the
full app — every screen, every interaction, real (if simplified) data flows. It is
NOT the tech stack we're building on, but it IS the source of truth for:
- Exact screen flow and navigation structure
- Exact copy/microcopy on every screen
- Exact interaction behavior (what taps what, what animates, what states exist)
- The provisional data shapes (see `docs/data-model.md`, extracted from this file)

When in doubt about how something should behave, open this file in a browser and
look at it before guessing. `reference/dropin-design-system.html` is the visual
language reference (colors, type, components) in isolation.

## Working style
- State a quick plan before large builds, then execute directly — don't ask for
  permission on small implementation details.
- Raw / unpolished / authentic Gen Z aesthetic throughout, per the design system —
  never let this drift toward generic clean-corporate SaaS styling.
- Grids of cards/tiles must be uniform size (aspect-ratio driven), always — this
  has been a recurring bug in the prototype and should never recur.
- Reuse one consistent fictional universe for any placeholder/seed data (people,
  places) rather than inventing new names per feature — see data-model.md for the
  existing cast if seed data is needed for local dev/testing.
- State management is Riverpod, locked — see docs/engineering.md for this and
  other project conventions that must stay consistent across sessions.
