# Engineering conventions

This is not a generic "how to write good code" doc — Claude Code already knows
that. This is the project-specific conventions that need to stay consistent
across sessions, since context resets between them and there's no second
engineer to catch drift. If it's not written here, assume it'll be reinvented
differently next session.

## State management: Riverpod
Use Riverpod for all app state. Don't mix in Provider, Bloc, or GetX in
different parts of the app — pick one pattern and keep it consistent across
every feature, even ones built in different sessions.

## Supabase schema changes: versioned migrations only
All schema changes go through versioned SQL migration files via the Supabase
CLI (`supabase migration new <name>`, then `supabase db push`). Never hand-edit
the schema through the Supabase dashboard for anything that should persist —
dashboard edits don't leave a reviewable history and can't be replayed on a
fresh environment. Check `supabase/migrations/` before assuming what the schema
currently looks like; don't infer it from application code alone.

## Secrets
All API keys (Supabase, Mux, Firebase) live in `.env`, loaded via
`flutter_dotenv` or equivalent — never hardcoded, never committed. `.env` must
be in `.gitignore` from the first commit. Provide a `.env.example` with the
required keys named but empty, so a fresh clone shows what's needed without
exposing real values.

## Folder structure
Feature-first, not layer-first — group by what the code does, not by what kind
of file it is:
```
lib/
  features/
    onboarding/       (splash, invite, taste selection, signin)
    map/              (map screen, pin rendering, place preview sheet)
    place/            (place page, video/reel viewer, comments)
    people/           (people list, profile pages, chat thread)
    inbox/
    profile/          (the signed-in user's own profile)
  core/
    supabase/         (client setup, query helpers)
    mux/               (video upload/playback helpers)
    theme/            (design system: colors, type, component styles)
    widgets/          (shared components used across 2+ features)
```
A screen or component used by exactly one feature lives in that feature's
folder. Only move something into `core/widgets` once a second feature actually
needs it — don't pre-emptively generalize.

## Design system as code, not per-screen values
Colors, type scales, and the glow/heat treatment described in
`docs/design-system.md` should be defined once in `core/theme/` and referenced
everywhere — never hardcode a hex value or a box-shadow string directly in a
screen file. This matters more than usual here because the whole visual
identity depends on a small, consistent palette (see design-system.md) — a
one-off hardcoded color is exactly how the "childish multi-hue" problem the
product already moved away from once would creep back in.

## Testing
- Any function touching money, auth, or RLS-gated data needs a test before it's
  considered done — these are the categories where a silent bug is expensive.
- Widget tests for core interaction patterns that repeat across the app (the
  bottom sheet → place page → video viewer chain, the commit → directions/bring-
  people transform) — these are exactly the places where the HTML prototype
  surfaced real bugs (event bubbling, pointer-capture issues), so the Flutter
  rebuild should have regression coverage for the same interaction chains.
- Straightforward UI-only screens with no business logic don't need heavy test
  coverage — use judgment, don't chase 100%.

## Git commits
Small, reviewable commits with a clear one-line summary of what changed and
why — not one giant commit per session. This matters specifically because
there's no second engineer reviewing in real time; commit messages are the
audit trail for a solo-founder-plus-agent workflow.

## Model usage (for whoever is driving Claude Code sessions)
Default to Sonnet 5 for day-to-day feature work — it's the current Claude Code
default and well-suited to well-specified implementation. Switch to Opus 4.8
specifically for one-time, hard-to-unwind architectural decisions: initial
schema design, RLS policy design, and the auth flow. Once those are set, switch
back to Sonnet 5 for building against them.
