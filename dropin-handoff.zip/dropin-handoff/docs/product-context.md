# Product context

## Thesis
DropIn's spine: **find the right people, through whom find the right places.**
People are the discovery mechanism and the trust wrapper — users don't search
places directly. A place is trustworthy because *someone like you* went there,
not because of a star rating.

## The wedge
Original idea was horizontal discovery ("what to do tonight"). Gen Z user testing
invalidated this: discovery already feels solved via IG/TikTok/Google, frictionless
convenience read as "taking the joy out" (real friction-maxxing/analog-revival
trend), and creators had no reason to migrate off their existing IG audience.

Current wedge: **the newcomer.** Someone new to San Francisco has no friend graph,
no local taste signal, and Google gives them tourist traps — discovery is
genuinely unsolved for them specifically. This is the seed/acquisition angle, not
the permanent identity: newcomers are a flow (~6–12 months), graduating into
locals who then onboard the next cohort. The broader long-term TAM is "find your
people in your city," generalized past just newcomers.

## Core mechanics (locked)
- **Drop** = short video + location + timestamp, posted by a real person.
- **Three temporal modes**, one warm-light family (not separate hues):
  - **LIVE** — happening right now, hottest/brightest
  - **RECENT** — happened recently, still relevant
  - **MEMORY** — a past favorite, dimmest
- **Invite-only access**, gated further by creator status (not everyone can drop
  content, only invited/qualified users — exact gating mechanic TBD in schema).
- **Commit action** (the "I'm in" / "join" moment) lives on the place page, not on
  home-screen cards. Home cards are a hook, not a decision surface. On LIVE drops
  specifically, a fast quick-join exists on the compact preview sheet too — this
  is the one exception, because live urgency beats depth.
- **Chat is scoped to drop/plan coordination**, not a general messenger. A
  lightweight 1:1 message thread (seeded/contextual) exists on profiles; this is
  intentionally not full DM/group-chat infrastructure. Do not expand this into a
  general messaging product without a deliberate new decision.
- **Creator incentive model**: network growth + scene reputation + real money
  (paid events, place commission). Money is a later-unlock, not day-one — a
  creator builds reputation with free drops first, money follows reputation.

## Newcomer emotional arc (why the onboarding flow is shaped the way it is)
Invite (personal, low-friction, emotional) → onboarding (rational case for the
product) → signin (the real ask: phone number, because it can match contacts to
show mutual people already on the app — the strongest proof-of-life a people-first
app can offer) → taste selection (one low-friction signal: scene/vibe tags, used
to compute real personalization like "you both love rooftops and natural wine")
→ home, which opens on **Places** by default (map-led), with a People tab as the
alternate door onto the same graph.

## Competitive positioning
Corner is the closest competitor and already does people→places discovery with a
similar trust framing — so DropIn's differentiation is NOT "trusted discovery"
alone. It leans on: the newcomer wedge specifically, the creator money layer, and
a warm/nocturnal/earnest visual identity vs. Corner's cool/airy/ironic one.

## Explicitly deferred (do not build unless re-scoped)
- Full group chat / general DM messaging
- A settings page beyond a basic stub
- Public-facing creator monetization tooling (money layer is conceptual/locked
  as a decision, not yet spec'd as a feature)
