# Design system

Full visual reference: `reference/dropin-design-system.html` (open in a browser).
This doc is the rules; that file is the rendered proof.

## Point of view
"The warm glow of a city at night when you've found your people." Warm,
nocturnal, human-lit, earnest — raw and unpolished, not clean-corporate SaaS.
This is a deliberate differentiator against cooler/ironic competitors — never let
implementation drift toward generic polish.

## Color
Base is warm espresso-black, never cold/pure black. One warm light family carries
all temporal meaning — do NOT introduce a multi-hue system (an earlier green/
orange/violet mode system was explicitly killed after user testing called it
"overused"/childish):
- **Flame** — hot white-amber — LIVE
- **Ember** — amber/orange — RECENT
- **Coal** — dim brown — MEMORY
- **Glow** — the CTA/commit amber, used for the primary action everywhere

Light mode exists (toggle) and must use its own darker/higher-contrast values for
glows and halos — a glow color tuned for a dark background is often invisible on
a light one; this was a real shipped bug in the prototype (fixed via light-mode-
scoped shadow overrides, not new colors). Any new glow/halo effect must be checked
in both modes.

## Type
- **Archivo Black** — display/headlines, with a warm glow text-shadow treatment
  (see prototype `.brand`/hero styles) — never plain flat black text for headline
  moments.
- **Space Grotesk** — UI and body text.
- **Permanent Marker** — used sparingly for handwritten/sticker-style accents
  (stamps, tags, playful asides) — not for primary content.

## Trust graph, made visible
This is a recurring, load-bearing visual pattern, not decoration: a person's
"closeness" to the user is always shown via glow intensity — bright amber ring =
"your people" (already followed/close), dim ring = local/host/not-yet-close. This
pattern repeats across map pins, the People list, and profile avatars. Any new
surface showing a person should use it.

## Iconography
Lucide icon set. Import/bundle it — never hand-draw icons, never leave an icon
name unregistered (a common prototype bug was referencing an icon name that
hadn't been added to the build's icon allowlist, causing silent blank icons).

## Grids
Any grid of photo tiles or cards (taste-selection chips, profile photo grids,
place drop-strips) must be **uniform size**, driven by aspect-ratio, not by
content height. A subtle per-tile rotation (1–3deg, alternating) is fine and
matches the "stickers on a corkboard" feel — true unevenness (rows of different
heights because captions wrap differently) is a bug and has been explicitly
flagged twice during prototyping. Always test with the longest realistic caption.

## Texture and voice
Film-grain/analog texture at low opacity is part of the identity (ties to the
Gen Z friction-maxxing/analog-revival insight from user research — polish reads
as inauthentic to this audience). Voice is warm and earnest, never ironic —
competitors in this space lean ironic/ironic-cool; sincerity is the
differentiator DropIn is allowed to use precisely because of the newcomer wedge.

## Components with locked behavior
- **Bottom sheet (map pin preview):** fast glance only — hero image with a
  play-icon affordance (implies video), mode badge, mini facepile, short why-line.
  No full commit button except on LIVE (a quick "join now"). Tapping the hero
  image specifically opens the video viewer; tapping elsewhere on the sheet opens
  the full place page.
- **Place page:** video-first hero, "your people's drops" strip, who's-going,
  a react row (this is the creator's core reward loop — do not cut), comments
  with live input. Committing transforms the action bar from a single "I'm in"
  button into two stacked actions: primary "get directions," secondary
  "bring people" — turning the highest-intent moment directly into the invite
  loop instead of a static confirmation.
- **Video/reel viewer:** full-screen vertical swipe through a place's drops,
  entered from the sheet hero or place-page hero/drop-strip. Known implementation
  trap: if an embedded video player captures pointer/touch events, it can block
  both navigation buttons and swipe gestures — disable pointer events on the
  video element itself and rely on your own chrome for interaction. Also watch
  for a close/back button nested inside a larger tappable card: a click can
  bubble up and re-trigger the parent's own tap handler, appearing to
  "reopen" the thing you just closed. Always stopPropagation on nested controls.
